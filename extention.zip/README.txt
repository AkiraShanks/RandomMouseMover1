15-Second Tab Switcher

Changes:
- Removed the "15 seconds" explanatory text from the popup.
- Added Google-style favicon icons.
- Alt+Q turns tab switching OFF.
- Alt+W turns tab switching ON.
- Tab switching remains every 15 seconds.
- The extension starts ON after installation.

Install:
1. Unzip this folder.
2. Open chrome://extensions
3. Enable Developer mode.
4. Click Load unpacked.
5. Select the extracted extension folder.

Keyboard shortcuts:
- Alt+Q = OFF
- Alt+W = ON

If Chrome reports that a shortcut is already in use, open:
chrome://extensions/shortcuts
and assign Alt+Q / Alt+W manually.
