const ALARM = "tab-switcher";
const DEFAULT_ENABLED = true;

async function setEnabled(enabled) {
  await chrome.storage.local.set({ enabled });
  if (enabled) {
    await chrome.alarms.create(ALARM, {
      delayInMinutes: 0.25,
      periodInMinutes: 0.25
    });
  } else {
    await chrome.alarms.clear(ALARM);
  }
}

async function getEnabled() {
  const result = await chrome.storage.local.get("enabled");
  return result.enabled ?? DEFAULT_ENABLED;
}

chrome.runtime.onInstalled.addListener(async () => {
  await setEnabled(DEFAULT_ENABLED);
});

chrome.runtime.onStartup.addListener(async () => {
  if (await getEnabled()) {
    await chrome.alarms.create(ALARM, {
      delayInMinutes: 0.25,
      periodInMinutes: 0.25
    });
  }
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM || !(await getEnabled())) return;

  const tabs = await chrome.tabs.query({ currentWindow: true });
  if (tabs.length < 2) return;

  const activeIndex = tabs.findIndex(t => t.active);
  if (activeIndex < 0) return;

  const nextIndex = (activeIndex + 1) % tabs.length;
  await chrome.tabs.update(tabs[nextIndex].id, { active: true });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.action === "start") {
      await setEnabled(true);
      sendResponse({ enabled: true });
    } else if (msg.action === "stop") {
      await setEnabled(false);
      sendResponse({ enabled: false });
    } else if (msg.action === "getStatus") {
      sendResponse({ enabled: await getEnabled() });
    }
  })();
  return true;
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "turn-off") {
    await setEnabled(false);
  } else if (command === "turn-on") {
    await setEnabled(true);
  }
});
