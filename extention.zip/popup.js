const status = document.getElementById("status");

function updateStatus(enabled) {
  status.textContent = enabled ? "ON" : "OFF";
}

function setEnabled(enabled) {
  chrome.runtime.sendMessage({ action: enabled ? "start" : "stop" }, (response) => {
    if (chrome.runtime.lastError) return;
    updateStatus(enabled);
  });
}

chrome.runtime.sendMessage({ action: "getStatus" }, (response) => {
  if (response) updateStatus(response.enabled);
});

document.getElementById("start").onclick = () => setEnabled(true);
document.getElementById("stop").onclick = () => setEnabled(false);
